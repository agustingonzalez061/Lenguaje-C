#include <stdio.h>
#include <stdlib.h>
#define CANT 5
int main()
{
    float sueldo [CANT];
    int edad [CANT];
    int leg [CANT];
    int i;
    for (i = 0; i <CANT; i ++)
    {
        leg [i]=i+1;
        printf("Ingrese edad: ");
        scanf("%d", &edad[i]);
        printf("Ingrese sueldo: ");
        scanf("%f", &sueldo[i]);
    }
    printf("\nLegajo \tEdad \tSueldo");
    for (i = 0; i<CANT; i ++)
    {
        printf("\n%d \t%d \t%.2f", leg [i], edad [i], sueldo [i]);
    }
    return 0;
}
