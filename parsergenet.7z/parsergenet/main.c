#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE *f;
    int cant;
    char id [20];
    char anio[20];
    char marca [50];
    char modelo [50];
    char color [50];
    int autoID;
    int anioANIO;
    f = fopen("dato.csv","r");
    if (f == NULL)
    {
        printf ("no se pudo abrir");
        exit(EXIT_FAILURE);
    }
    while (!(feof(f)))
    {
        cant = fscanf(f,"%[^,], %[^,], %[^,], %[^,], %[^\n] \n", id, marca,modelo,color,anio);
        if ( cant !=5)
        {
            if(feof(f))
            {
                break;
            }

            else
            {
                printf("hubo un error");
                exit(EXIT_FAILURE);
            }
        }



        autoID = atoi(id);
        anioANIO = atoi(anio);
        printf("%4d, %15s, %16s, %15s, %4d \n", autoID, marca,modelo,color,anioANIO);

    }
    fclose(f);
    return 0;
}
