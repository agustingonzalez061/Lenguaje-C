#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE *f;
    int cant;
    int d1,d2,d3,d4;
    f = fopen("numeros.txt", "r");
    if(f == NULL)
    {
        printf("No se pudo abrir el archivo\n");
        exit(EXIT_FAILURE);
    }
    while (!(feof (f)))
    {
        cant =fscanf(f,"%d, %d, %d, %d ,\n", &d1,&d2, &d3, &d4);
        if ( cant !=4)
        {
            if(feof(f))
            {
                break;
            }

            else
            {
                printf("hubo un error");
                exit(EXIT_FAILURE);
            }
        }

        printf("%d, %d, %d, %d\n", d1,d2, d3, d4);
    }
    fclose(f);
    return 0;
}
