#include <stdio.h>
#include <stdlib.h>
typedef struct
{
    char id [20];
    char anio[20];
    char marca [50];
    char modelo [50];
    char color [50];
    int autoID;
    int anioANIO;
} autos;
int main()
{
    FILE *f;
    autos auto1;
    int cant;
    f = fopen("dato.csv","r");
    if (f == NULL)
    {
        printf ("no se pudo abrir");
        exit(EXIT_FAILURE);
    }
    while (!(feof(f)))
    {
        cant = fscanf(f,"%[^,], %[^,], %[^,], %[^,], %[^\n] \n", auto1.id, auto1.marca,auto1.modelo,auto1.color,auto1.anio);
        if ( cant !=5)
        {
            if(feof(f))
            {
                break;
            }

            else
            {
                printf("hubo un error");
                exit(EXIT_FAILURE);
            }
        }



        auto1.autoID = atoi(auto1.id);
        auto1.anioANIO = atoi(auto1.anio);
        printf("%4d %15s %16s %15s %4d \n", auto1.autoID, auto1.marca,auto1.modelo,auto1.color,auto1.anioANIO);

    }
    fclose(f);
    return 0;
}
