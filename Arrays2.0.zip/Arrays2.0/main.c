#include <stdio.h>
#include <stdlib.h>
#define CANT 3
int main()
{
    int legajo [CANT];
    char nombre [CANT][31];
    float salario [CANT];
    int i;
    for (i = 0; i < CANT ; i++)
    {
        legajo [i]= i + 1;
        printf ("Nombre: ");
        fflush(stdin);
        scanf ("%[^\n]", nombre [i]);
        printf ("Salario: ");
        fflush(stdin);
        scanf ("%f", &salario [i]);

    }
    printf("\nLegajo \tnombre \tSalario");
    for (i = 0; i<CANT; i ++)
    {
        printf("\n%d \t%s \t%.2f", legajo [i], nombre [i], salario [i]);
    }
    return 0;
}
