#include <stdio.h>
#include <stdlib.h>

int main()
{
    /*int *x;
    int v = 10;
    x = &v;
    printf("%d\n",v);
    *x = 90;
    printf("%d\n",v);
    printf("%p\n",&v);
    printf("%p\n",&x);
    printf("%d\n",*x);*/

    char * pLetra = NULL;
    char letra;
    pLetra = &letra;
    printf ("ingresen un char: ");
    fflush(stdin);
    scanf("%c", pLetra);
    printf("%c",*pLetra);
    return 0;
}
